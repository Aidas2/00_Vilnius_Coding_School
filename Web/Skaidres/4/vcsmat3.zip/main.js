$(document).ready(function() {
	$("#paspausti").click(function() {
		alert('Tekstas kokio mums reik');
	});

	$("#vardas_spausti").click(function() {
		var vardas = $("#vardas").val();
		alert('Labas, tavo vardas yra '+vardas);
	});

	$("#skaiciuoti").click(function() {
		var x = Number($("#sk1").val());
		var y = Number($("#sk2").val());
		alert(x+y);
	})
});