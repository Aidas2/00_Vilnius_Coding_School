$(document).ready(function(){
    $('select').formSelect();

	$("#paspausti").click(function() {
		alert('Tekstas kokio mums reik');
	});

	$("#vardas_spausti").click(function() {
		var vardas = $("#vardas").val();
		alert('Labas, tavo vardas yra '+vardas);
	});

	$("#skaiciuoti").click(function() {
		var x = Number($("#sk1").val());
		var y = Number($("#sk2").val());
		alert(x+y);
	});

	$("#spalva").change(function() {
			var spalva = $("#spalva").val();
			$("body").removeClass().addClass(spalva);
	});




























	$("#skaiciuoti_kalkuliatoriu").click(function() {
		var x = Number($("#skaicius1").val());
		var y = Number($("#skaicius2").val());
		var zenklas = Number($("#pasirinkimas").val());
		switch(zenklas) {
			case 1:
				alert(x+y);
				break;
			case 2:
				alert(x-y);
				break;
			case 3:
				alert(x*y);
				break;
			case 4:
				alert(x/y);
				break;
		}
		if(zenklas == 1) {
			alert(x+y);
		} else if(zenklas == 2) {
			alert(x-y);
		} else if(zenklas == 3) {
			alert(x*y);
		} else if(zenklas == 4) {
			alert(x/y);
		}

	});
});